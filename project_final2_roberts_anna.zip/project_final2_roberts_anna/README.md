# URL
[Git Hub Link](https://github.com/AnnaRoberts/project_final2_roberts_anna.git)

#Web Host 
[ Web Host Link](http://www.dandeliondesigncompany.com/project_final2_roberts_anna/)

* Images not working. Please see comments

# Resources
* [ Leaky Cauldron Info](https://www.pottermore.com/writing-by-jk-rowling/the-leaky-cauldron)
* [Media query to change to secondar logo](http://stackoverflow.com/questions/21400065/swap-out-3-differently-sized-logos-with-media-queries)

#Comments* Just to be clear I am NO Gryffindor hater ;) I just feel that I wanted to push the color scheme further than the obvious reds and golds.* I applied almost all the suggestions from class: adding a drop shadow, increasing the size of the bricks, I kept the script secondary font, because I agree with you I think it adds a nice Harry Potter feel to the site. * I attempted to add a media query and change the logo to a secondary, smaller logo for mobile viewers. I could not get it to work. I commented it out in my CSS (line 87) so you could take a look and see why it is not working. I think it is something with using the h1 element. * I emailed you on Friday at about 3pm about the images not working. I tried everything from changing the file type, resizing, moving into a different folder, reloading individually, and cannot figure out what is wrong. On my index everything is fine and there are no errors from dev tools or the W3 unicorn validator. I have not heard any feedback from you, and can not figure out what is wrong on my own. If you could please let me know I would be happy to fix it, but I am stumped. I have been using Cyber Duck for about a year now and have had zero issues. It is frustrating because it seems fine on my index, I truly hope this does not affect my grade as my index shows no errors and I don't know what  else to try. 
* I look forward to the rest of your feedback! 